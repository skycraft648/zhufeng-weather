﻿import sys
sys.path.insert(0, '.')
from weather_ml import _temperature_feel
v = _temperature_feel(30)
print(repr(v))
print('Length:', len(v))
for c in v:
    print(f'  U+{ord(c):04X}')
