﻿import requests, json
r = requests.get('https://archive-api.open-meteo.com/v1/archive', params={
    'latitude': 31.23, 'longitude': 121.47,
    'start_date': '2026-06-01', 'end_date': '2026-06-10',
    'daily': 'temperature_2m_mean',
    'timezone': 'Asia/Shanghai',
}, timeout=10)
print('Status:', r.status_code)
data = r.json()
print('Keys:', list(data.keys()))
if 'daily' in data:
    print('Daily keys:', list(data['daily'].keys()))
    print('Days:', len(data['daily']['time']))
    print('Temps:', data['daily']['temperature_2m_mean'])
