﻿import sys
sys.path.insert(0, '.')
from weather_analysis import detect_changes, uv_level, wind_direction
from weather_codes import weather_info
from weather_service import Location, _location_rank
from weather_ml import (
    generate_briefing, _temperature_feel, _humidity_feel,
    cluster_weather,
    _daily_feature_matrix, _describe_cluster,
)
import pandas as pd

passed = 0
failed = 0

def check(name, condition):
    global passed, failed
    if condition:
        passed += 1
        print(f'  PASS: {name}')
    else:
        failed += 1
        print(f'  FAIL: {name}')

print('--- Existing tests ---')
desc, icon, cat = weather_info(0)
check('weather_info(0)', desc == '晴天')

check('uv_level(7)', uv_level(7) == '高')
check('wind_direction(90)', wind_direction(90) == '东')

capital = Location(name='北京', latitude=39.9075, longitude=116.39723, country='中国', admin1='北京市', admin2='北京市', country_code='CN', feature_code='PPLC', population=18960744)
namesake = Location(name='北京', latitude=30.72608, longitude=108.67483, country='中国', admin1='重庆市', admin2='重庆市', country_code='CN', feature_code='PPL')
ranked = sorted([namesake, capital], key=lambda item: _location_rank(item, '北京'), reverse=True)
check('location_ranking', ranked[0] == capital)

frame = pd.DataFrame({
    'time': pd.date_range('2026-06-12 08:00', periods=5, freq='h'),
    'weather_code': [0, 1, 2, 61, 61],
    'precipitation_probability': [0, 10, 30, 70, 80],
    'precipitation': [0]*5, 'temperature_2m': [25]*5, 'wind_gusts_10m': [10]*5,
})
msgs = detect_changes(frame)
check('detect_changes', any('雨' in m for m in msgs))

print()
print('--- ML / AI tests ---')
check('temp_feel_35', '热' in _temperature_feel(35))
check('temp_feel_25', '暖' in _temperature_feel(25))
check('temp_feel_-5', _temperature_feel(-5) == '严寒')
check('humidity_feel_90', _humidity_feel(90) == '潮湿')
check('humidity_feel_20', _humidity_feel(20) == '干燥')

current = {'temperature_2m': 22.0, 'relative_humidity_2m': 55, 'wind_speed_10m': 10, 'cloud_cover': 20, 'apparent_temperature': 21.0, 'precipitation': 0}
hourly = pd.DataFrame({
    'time': pd.date_range('2026-06-12 08:00', periods=24, freq='h'),
    'temperature_2m': [20+i*0.5 for i in range(24)],
    'relative_humidity_2m': [55]*24,
    'apparent_temperature': [19+i*0.5 for i in range(24)],
    'precipitation_probability': [10]*24,
    'precipitation': [0]*24,
    'weather_code': [1]*24, 'cloud_cover': [30]*24,
    'visibility': [10000]*24, 'wind_speed_10m': [10]*24,
    'wind_gusts_10m': [15]*24, 'uv_index': [3]*24,
})
daily = pd.DataFrame({
    'time': pd.date_range('2026-06-12', periods=3, freq='D'),
    'weather_code': [1,1,1],
    'temperature_2m_max': [28,30,26],
    'temperature_2m_min': [18,20,16],
    'precipitation_probability_max': [20,10,60],
    'uv_index_max': [5,6,2],
})
briefing = generate_briefing(current, hourly, daily)
check('briefing_summary', len(briefing.summary) > 0)
check('briefing_highlights', len(briefing.highlights) > 0)
check('briefing_outlook', len(briefing.outlook) > 0)

high_current = dict(current, temperature_2m=36, apparent_temperature=35)
b2 = generate_briefing(high_current, hourly, daily)
check('high_temp_alert', any('高温' in h or '暑' in h for h in b2.highlights))

r1 = generate_briefing(current, hourly, daily, seed=42)
r2 = generate_briefing(current, hourly, daily, seed=42)
check('seed_deterministic', r1.summary == r2.summary)


cluster_result = cluster_weather(pd.concat([daily]*3))
if cluster_result is None:
    print('  SKIP: Cluster tests (scikit-learn not installed)')
else:
    check('cluster_count', cluster_result.n_clusters >= 2)
    check('cluster_labels', len(cluster_result.labels) == 9)
    check('cluster_centroids', len(cluster_result.centroids) == cluster_result.n_clusters)
    check('cluster_names', len(cluster_result.cluster_names) == cluster_result.n_clusters)
    check('cluster_current', cluster_result.current_cluster == cluster_result.labels[0])
    check('cluster_elbow', len(cluster_result.elbow_data) >= 1)

matrix = _daily_feature_matrix(pd.concat([daily]*2))
check('feature_matrix_shape', matrix.shape == (6, 4))
check('feature_matrix_range', matrix.max() <= 1.0 and matrix.min() >= 0.0)

cdesc = _describe_cluster({'temperature_2m_max': 35, 'temperature_2m_min': 28, 'precipitation_probability_max': 10, 'uv_index_max': 8})
check('describe_cluster_name', len(cdesc[0]) > 0)
check('describe_cluster_detail', len(cdesc[1]) > 0)

print()
print(f'=== {passed} passed, {failed} failed ===')
