﻿import sys; sys.path.insert(0, '.')
from weather_ml import generate_briefing, _temperature_feel
import pandas as pd, traceback

def make_current(temp=22.0, rh=55, wind=10, cloud=30, apparent=21.0, precip=0.0):
    return {"temperature_2m": temp, "relative_humidity_2m": rh, "wind_speed_10m": wind,
            "cloud_cover": cloud, "apparent_temperature": apparent, "precipitation": precip}

size = 24
temps = [20 + i * 0.5 for i in range(size)]
hourly = pd.DataFrame({
    "time": pd.date_range("2026-06-12 08:00", periods=size, freq="h"),
    "temperature_2m": temps, "relative_humidity_2m": [55]*size,
    "apparent_temperature": [t-1 for t in temps], "precipitation_probability": [10]*size,
    "precipitation": [0]*size, "weather_code": [1]*size, "cloud_cover": [30]*size,
    "visibility": [10000]*size, "wind_speed_10m": [10]*size,
    "wind_gusts_10m": [15]*size, "uv_index": [3]*size,
})

print("hourly columns:", hourly.columns.tolist())
print("hourly shape:", hourly.shape)

# Test daily_df with default args
try:
    daily = pd.DataFrame({
        "time": pd.date_range("2026-06-12", periods=3, freq="D"),
        "weather_code": [1]*3, "temperature_2m_max": [28,30,26],
        "temperature_2m_min": [18,20,16],
        "precipitation_probability_max": [20,10,60], "uv_index_max": [5,6,2],
    })
    print("daily created OK, shape:", daily.shape)
except Exception as e:
    print("daily FAILED:", e)
    traceback.print_exc()

# Test briefing
try:
    current = make_current(22, 55, 10, 20, 21)
    result = generate_briefing(current, hourly, daily)
    print("Result type:", type(result))
    if result is None:
        print("RESULT IS NONE!")
    else:
        print("summary:", result.summary[:50])
        print("highlights:", result.highlights)
        print("outlook:", result.outlook[:50])
except Exception as e:
    print("generate_briefing RAISED:", e)
    traceback.print_exc()

# Test with cold temp
try:
    current2 = make_current(-3, 50, 5, 20, -5)
    result2 = generate_briefing(current2, hourly, daily)
    print("\nCold test result type:", type(result2))
    if result2 is None:
        print("COLD RESULT IS NONE!")
    else:
        print("highlights:", result2.highlights)
except Exception as e:
    print("cold briefing RAISED:", e)
    traceback.print_exc()
